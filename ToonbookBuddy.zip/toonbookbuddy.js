chrome.browserAction.setBadgeBackgroundColor({color: [0, 191, 255, 255]});
