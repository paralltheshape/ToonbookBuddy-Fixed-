# ToonbookBuddy
A helpful Chrome extension for Toonbook users.

Official build: https://chrome.google.com/webstore/detail/toonbook-buddy/pllgbikcebaondodhcdojmmijidllhla

A simple way to build Toonbook Buddy is to make the contents a .zip file, and load it using Developer Tools.
